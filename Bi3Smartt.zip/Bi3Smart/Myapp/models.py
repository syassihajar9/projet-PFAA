from django.db import models
import datetime
from django.contrib.auth.models import User
from shortuuid.django_fields import ShortUUIDField
from django.utils.html import mark_safe

STATUS_CHOICE=(
    ("expédié", "expédié"),
    ("livré" , "livré"),
)

def directory_path(instance,filename):
    return 'user_{0}/{1}'.format(instance.id_pro, filename)

class Produit(models.Model):
    id_pro = ShortUUIDField(unique=True, length=5, max_length=10,alphabet="abcdefg1234567890")
    nom = models.CharField(max_length=100)
    image = models.ImageField(upload_to=directory_path , default="product.jpg")
    description = models.TextField()
    prix = models.DecimalField(max_digits=10, decimal_places=2)
    qte_stock = models.CharField(max_length=100,null=True, blank=True)
    disponible = models.BooleanField(default=True)
    def image_produit(self):
        return mark_safe('<img src="%s" width="50" height="50">' % (self.image.url))
    def __str__(self):
        return self.nom

class Panier(models.Model):
    utilisateur = models.ForeignKey(User, on_delete=models.CASCADE)
    produits = models.ManyToManyField(Produit)

    def __str__(self):
        return f"Panier de {self.utilisateur.username}"

class Commande(models.Model):
    utilisateur = models.ForeignKey(User, on_delete=models.CASCADE)
    total_price = models.DecimalField(max_digits=10,decimal_places=2)
    statut = models.BooleanField(default=False)
    date_creation = models.DateTimeField(auto_now_add=True)
    product_status = models.CharField(choices = STATUS_CHOICE , max_length=30 , default="expédié")
    def __str__(self):
        return f"Commande de {self.utilisateur.username}"

class Utilisateur(models.Model):
    id_utilisateur = ShortUUIDField(unique=True, length=5, max_length=10 ,alphabet="abcdefg1234567890")
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    nom = models.CharField(max_length=100 , default="user")
    prenom = models.CharField(max_length=100 , default="")
    adresse = models.CharField(max_length=255 , default="")
    telephone = models.CharField(max_length=20 , default="")
    def __str__(self):
        return self.user.username

class Administrateur(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    def __str__(self):
        return self.user.username

class Client(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.user.username
    




