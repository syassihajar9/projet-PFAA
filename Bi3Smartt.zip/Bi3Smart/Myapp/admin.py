from django.contrib import admin
from Myapp.models import Produit, Panier, Commande
from django.utils.html import mark_safe

class ProduitAdmin(admin.ModelAdmin):
    list_display = ['id_pro' , 'nom' , 'image_produit' , 'prix' ,'qte_stock' , 'disponible'  ]
    def image_produit(self, obj):
        return mark_safe('<img src="%s" width="50" height="50">' % obj.image.url)
    image_produit.short_description = 'image'
    
class CommandeAdmin(admin.ModelAdmin):
    list_display = ['total_price' , 'statut' , 'date_creation' ,'product_status']
    
admin.site.register(Produit,ProduitAdmin)
admin.site.register(Panier)
admin.site.register(Commande,CommandeAdmin)
