from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm 
from .form import CustomUserCreationForm
from django.contrib.auth import login, authenticate, logout
from Myapp.models import Produit, Panier, Commande, Utilisateur
from django.contrib.auth.decorators import login_required
from django.contrib import messages 
import google.generativeai as genai
from django.http import JsonResponse
import json
import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv('GEMINI_API_KEY')
genai.configure(api_key=API_KEY)
def chat_view(request):
    
    if request.method == 'POST':
        # Obtenez le message de l'utilisateur à partir du formulaire
        user_input = request.POST.get('user_input', '')

        # Utilisez le modèle de génération pour obtenir la réponse du chatbot
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(user_input)
        bot_response = ''.join([p.text for p in response.candidates[0].content.parts])

        # Renvoyez le message de l'utilisateur et la réponse du chatbot au template
        return render(request, 'chat.html', {'user_input': user_input, 'bot_response': bot_response})

    return render(request, 'chat.html')

def index(request):
    products = Produit.objects.all()
    context = {
        "products":products,
    }
    return render(request,'Myapp/index.html',context)

def chatbot(request):
    return render(request, 'chatbot.html')

def getResponse(request):
    userMessage = request.GET.get('userMessage')
    return HttpResponse(userMessage)

def inscription(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('connexion')
    else:
        form = CustomUserCreationForm()
    return render(request, 'inscription.html', {'form': form})

def connexion(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('acceuil')
        else:
            messages.error(request, 'Nom d\'utilisateur ou mot de passe incorrect.')
    return render(request, 'connexion.html')

@login_required
def acceuil(request):
    return render(request, 'acceuil.html')

def deconnexion(request):
    logout(request)
    return redirect('connexion')

def produit_detail(request,id_pro):
    produit = Produit.objects.get(id_pro=id_pro)
    context = {
        "produit":produit,
    }
    return render(request,'Myapp/product_detail.html',context)


@login_required
def ajouter_au_panier(request, produit_id):
    produit = Produit.objects.get(id_pro=produit_id)
    panier, created = Panier.objects.get_or_create(utilisateur=request.user)
    panier.produits.add(produit)
    messages.success(request, f"{produit.nom} a été ajouté à votre panier.")
    return redirect('liste_produits')

# Vue pour afficher le contenu du panier
@login_required
def voir_panier(request):
    panier = Panier.objects.get(utilisateur=request.user)
    produits = panier.produits.all()
    return render(request, 'voir_panier.html', {'produits': produits})

# Vue pour supprimer un produit du panier
@login_required
def supprimer_du_panier(request, produit_id):
    produit = Produit.objects.get(id_pro=produit_id)
    panier = Panier.objects.get(utilisateur=request.user)
    panier.produits.remove(produit)
    messages.success(request, f"{produit.nom} a été supprimé de votre panier.")
    return redirect('voir_panier')

# Vue pour passer une commande
@login_required
def passer_commande(request):
    panier = Panier.objects.get(utilisateur=request.user)
    total_price = sum(produit.prix for produit in panier.produits.all())
    Commande.objects.create(utilisateur=request.user, total_price=total_price)
    panier.produits.clear()
    messages.success(request, "Votre commande a été passée avec succès.")
    return redirect('voir_panier')
# Vue pour afficher l'historique des commandes de l'utilisateur
@login_required
def historique_commandes(request):
    commandes = Commande.objects.filter(utilisateur=request.user)
    return render(request, 'historique_commandes.html', {'commandes': commandes})

# Vue pour modifier les informations de l'utilisateur
@login_required
def modifier_informations_utilisateur(request):
    if request.method == 'POST':
        utilisateur = Utilisateur.objects.get(user=request.user)
        utilisateur.nom = request.POST['nom']
        utilisateur.prenom = request.POST['prenom']
        utilisateur.adresse = request.POST['adresse']
        utilisateur.telephone = request.POST['telephone']
        utilisateur.save()
        messages.success(request, "Vos informations ont été mises à jour avec succès.")
        return redirect('modifier_informations_utilisateur')
    else:
        utilisateur = Utilisateur.objects.get(user=request.user)
        return render(request, 'modifier_informations_utilisateur.html', {'utilisateur': utilisateur})
    





