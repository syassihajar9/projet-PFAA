from django.urls import path
from. import views
from Myapp.views import index,produit_detail, ajouter_au_panier, voir_panier, supprimer_du_panier, passer_commande, historique_commandes, modifier_informations_utilisateur
app_name= "Myapp"
urlpatterns = [
    path("",index , name="index"),
    path("product/<id_pro>/" , produit_detail , name="product_detail"),

    path('getResponse',views.getResponse,name="getResponse"),

    path('ajouter-au-panier/<str:produit_id>/', ajouter_au_panier, name='ajouter_au_panier'),
    path('voir-panier/', voir_panier, name='voir_panier'),
    path('supprimer-du-panier/<str:produit_id>/', supprimer_du_panier, name='supprimer_du_panier'),
    path('passer-commande/', passer_commande, name='passer_commande'),
    path('historique-commandes/', historique_commandes, name='historique_commandes'),
    path('modifier-informations-utilisateur/', modifier_informations_utilisateur, name='modifier_informations_utilisateur'),
    ]


